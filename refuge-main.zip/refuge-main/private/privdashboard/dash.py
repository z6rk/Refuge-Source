import privdashboard.app.app as app

def openDash(init_bot, port=5000):
    app.startApp(init_bot, port=port)