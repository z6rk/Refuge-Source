__title__ = "Saiv_Utils"
__version__ = "1.0.0"
__author__ = "saiv#3777"
__license__ = "Professional Skid"