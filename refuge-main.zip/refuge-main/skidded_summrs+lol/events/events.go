package events

import (
	"fmt"
	"sync"

	"github.com/bwmarrin/discordgo"
	"github.com/notsaiv/lol/database"
	"github.com/notsaiv/lol/utils"
)

func BanHandler(s *discordgo.Session, event *discordgo.GuildBanAdd) {
	data, err := database.Database.FindData(s, event.GuildID)
	if err != nil {
		return
	}

	if data["massban"].(string) == "False" {
		return
	}

	utils.ReadAudit(s, event.GuildID, "Anti-Ban Triggered.", 22)
}


func GuildUpdate(s *discordgo.Session, event *discordgo.GuildUpdate) {
	guildData, err := database.Database.FindData(s, event.ID)
	if err != nil {
		return
	}

	entry, _, err := utils.FindAudit(s, event.Guild.ID, 1)
	if entry == nil || (err != nil && err.Error() != "Whitelisted") {
		return
	}

	for _, change := range entry.Changes {
		var key = *change.Key

		switch key {

		case discordgo.AuditLogChangeKeyVanityURLCode:

			switch {
			case guildData["vanity_protect"].(string) == "False":
				continue
			case change.OldValue == nil:
				continue

			default:
				jsonData := []byte(fmt.Sprintf(`{"code":"%s"}`, guildData["vanity-url"].(string)))
				utils.MakeRequest("PATCH", fmt.Sprintf("https://discord.com/api/v9/guilds/%s/vanity-url", event.Guild.ID), s.Token, jsonData)
			}
		}
	}
}


func Ready(s *discordgo.Session, event *discordgo.Ready) {
	s.UpdateStreamingStatus(2, fmt.Sprintf("%%help | Shard %d/%d", s.ShardID + 1, s.ShardCount), "https://twitch.tv/discord")
	fmt.Printf("Connected to shard #%d\n", s.ShardID)
}

var (
	guilds      = make(map[string]int)
	GuildCount  int
	MemberCount int
	muteX       = &sync.RWMutex{}
)
