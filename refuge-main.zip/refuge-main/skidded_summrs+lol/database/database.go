package database

import (
	"context"
	"fmt"

	"github.com/bwmarrin/discordgo"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)


func (db *MongoDB) FindData(s *discordgo.Session, guildID string) (bson.M, error) {
	var data bson.M
	if err = db.Collection.FindOne(context.Background(), bson.M{"guild_id": guildID}).Decode(&data); err != nil {
		_, err := s.State.Guild(guildID)
		if err != nil {
			return nil, err
		}

		return nil, fmt.Errorf("Guild doesn't exist in the database please reinvite it")
	}

	return data, nil
}

func (db *MongoDB) SetData(typeKey, guildID, index, value string) (bool, error) {
	if _, err = db.Collection.UpdateOne(context.Background(), bson.M{"guild_id": guildID}, bson.M{typeKey: bson.M{index: value}}, &options.UpdateOptions{}); err != nil {
		return false, err
	}
	return true, nil
}

func (db *MongoDB) IsWhitelisted(s *discordgo.Session, guildID, typeKey, ID string, optionalMember *discordgo.Member) bool {
	var (
		data bson.M
		err  error
	)

	data, err = db.FindData(s, guildID)
	if err != nil {
		return false
	}

	for _, whitelistedID := range data[typeKey].(bson.A) {
		if whitelistedID.(string) == ID {
			return true
		}
	}

	if optionalMember == nil {
		return false
	}

	for _, whitelistedRoleID := range data["whitelisted-roles"].(bson.A) {
		for _, roleID := range optionalMember.Roles {
			if whitelistedRoleID.(string) == roleID {
				return true
			}
		}
	}

	return false
}

func SetupDB() MongoDB {
	var db = MongoDB{}

	db.Client, err = mongo.NewClient(options.Client().ApplyURI("mongodb+srv://venue:saiv@botsdb.ihs3a.mongodb.net/refuge?retryWrites=true&w=majority"))

	if err != nil {
		panic(err)
	}

	err = db.Client.Connect(db.Ctx)
	if err != nil {
		panic(err)
	}

	db.Database = db.Client.Database("refuge")
	db.Collection = db.Database.Collection("server-data")
	fmt.Printf("MongoDB Connected\n")
	return db
}

var (
	cancel   func()
	Database = SetupDB()
	err      error
)

type (
	MongoDB struct {
		Collection *mongo.Collection
		Client     *mongo.Client
		Ctx        context.Context
		Database   *mongo.Database
	}
)
