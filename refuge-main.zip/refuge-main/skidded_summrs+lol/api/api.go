package api

import (
	"fmt"

	"github.com/notsaiv/lol/events"

	"github.com/bwmarrin/discordgo"
)

func (b *Bot) Run() {
	for _, session := range b.Sessions {
		if session != nil {
			session.Open()
		}
	}
}

func (b *Bot) Shard(token string, shardCount, shardID int) {

	// ** Setup session ** //

	s, err := discordgo.New(fmt.Sprintf("Bot %s", token))

	if err != nil {
		fmt.Printf("[Error on shard %d]: %s | retrying...", shardID, err.Error())
		b.Shard(token, shardCount, shardID)
	}

	s.ShardCount = shardCount
	s.ShardID = shardID

	s.Identify.Intents = discordgo.MakeIntent(discordgo.IntentsAllWithoutPrivileged | discordgo.IntentsGuildMembers)

	// ** Handlers ** //

	handlers := []interface{}{
		events.BanHandler,
		events.GuildUpdate,
		events.Ready,
	}

	for _, handler := range handlers {
		s.AddHandler(handler)
	}

	b.Sessions[shardID] = s
}

func (b *Bot) Stop() {
	for _, session := range b.Sessions {
		session.Close()
	}
}

type (
	Bot struct {
		Sessions []*discordgo.Session
	}
)